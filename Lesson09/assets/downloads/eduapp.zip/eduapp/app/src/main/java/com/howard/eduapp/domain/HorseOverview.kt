package com.howard.eduapp.domain

data class HorseOverview(val id: String, val name: Name, val age: UInt)