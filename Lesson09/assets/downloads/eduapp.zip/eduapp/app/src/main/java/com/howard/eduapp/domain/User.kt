package com.howard.eduapp.domain

data class User(val id: String, val email: Email)