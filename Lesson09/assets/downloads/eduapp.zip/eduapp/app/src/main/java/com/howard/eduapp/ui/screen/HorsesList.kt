package com.howard.eduapp.ui.screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.unit.dp
import com.howard.eduapp.domain.HorseOverview
import com.howard.eduapp.integration.firebase.firestore.Service
import com.howard.eduapp.ui.components.horse.HorseListItem

@Composable
fun HorsesList(onclick: (id: String) -> Unit) {
    val service = remember { Service() }
    var models by remember { mutableStateOf<List<HorseOverview>>(emptyList()) }

    LaunchedEffect(key1 = Unit) {
        models = service.getHorses()
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        models.forEach { HorseListItem(it) { onclick(it.id) } }
    }
}