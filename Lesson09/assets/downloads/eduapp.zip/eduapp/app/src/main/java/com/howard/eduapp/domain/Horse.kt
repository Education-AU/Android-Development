package com.howard.eduapp.domain

data class Horse(val id: String, val name: Name, val age: UInt)