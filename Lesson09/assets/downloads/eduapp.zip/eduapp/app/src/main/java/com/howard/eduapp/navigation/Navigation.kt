package com.howard.eduapp.navigation


import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.howard.eduapp.domain.Horse
import com.howard.eduapp.integration.firebase.auth.Service
import com.howard.eduapp.ui.components.horse.HorseDetailsItem
import com.howard.eduapp.ui.screen.HorsesList
import com.howard.eduapp.ui.screen.auth.SignIn
import com.howard.eduapp.ui.screen.auth.SignUp
import kotlinx.coroutines.launch

@Composable
fun Navigation() {//1234qweQWE!  test1@net.dk
    val scope = rememberCoroutineScope()
    val service = remember { Service() }
    val horseService = remember { com.howard.eduapp.integration.firebase.firestore.Service() }
    val controller = rememberNavController()
    var isLoggedIn by remember { mutableStateOf(false) }
    LaunchedEffect(key1 = isLoggedIn) {
        if (isLoggedIn) {
            controller.navigate("Horses")
        } else {
            controller.navigate("signUp")
        }
    }
    Column {

        NavHost(controller, startDestination = "signUp") {
            composable(route = "signUp") {
                SignUp(toSignIn = { controller.navigate("signIn") }) { email, password ->
                    scope.launch {
                        val res = service.signup(email, password)
                        isLoggedIn = res.isOk()
                    }
                }
            }
            composable(route = "signIn") {
                SignIn(
                    toSignUp = { controller.navigate("signUp") }) { email, password ->
                    scope.launch {
                       isLoggedIn=false
                        val res = service.signIn(email, password)
                        isLoggedIn = res.isOk()
                    }
                }
            }
            composable(route = "horses") {
                HorsesList {
                    controller.navigate("horse/$it")
                }
            }
            composable(route = "horse/{id}") {
                val id = it.arguments?.getString("id") ?: ""
                var horse by remember { mutableStateOf<Horse?>(null) }
                LaunchedEffect(key1 = Unit) {
                    horse = horseService.getHorse(id)
                }
                if (horse == null) {
                    Text("Some error should be handled")
                } else {
                    HorseDetailsItem(horse!!)
                }
            }
        }
    }

}