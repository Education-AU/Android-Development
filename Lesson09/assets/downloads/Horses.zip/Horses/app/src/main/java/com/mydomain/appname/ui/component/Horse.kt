package com.mydomain.appname.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.mydomain.appname.integration.firestore.model.HorseFS
import com.mydomain.appname.model.Horse

@Composable
fun Horse(horse: Horse) {
    Column {
        Text(horse.id)
        Text(horse.name)
    }
}