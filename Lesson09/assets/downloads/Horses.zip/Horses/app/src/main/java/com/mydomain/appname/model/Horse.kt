package com.mydomain.appname.model

data class Horse(val id:String,val name:String)