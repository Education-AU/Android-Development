package com.mydomain.appname.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.mydomain.appname.HorseService.HorseService
import com.mydomain.appname.integration.firestore.model.HorseFS
import com.mydomain.appname.model.Horse
import com.mydomain.appname.ui.components.Horse

@Composable
fun Horses() {
    val service = HorseService()
    var horses by remember { mutableStateOf<List<Horse>>(emptyList()) }
    LaunchedEffect(Unit) {
        horses = service.getAllHorses()
    }

    Column {
        horses.map { Horse(it) }
    }
}