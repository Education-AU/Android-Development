package com.mydomain.appname.HorseService

import com.mydomain.appname.integration.firestore.FSHorsesService
import com.mydomain.appname.model.Horse

class HorseService {

    val fsService: FSHorsesService = FSHorsesService()

    suspend fun getAllHorses(): List<Horse> {
        return fsService.getHorses().map { Horse(it.id, it.Name ?: "") }
    }
}