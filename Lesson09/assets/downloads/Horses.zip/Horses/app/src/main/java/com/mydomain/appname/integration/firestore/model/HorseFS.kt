package com.mydomain.appname.integration.firestore.model

data class HorseFS(var id: String = "", val Name: String? = null)
