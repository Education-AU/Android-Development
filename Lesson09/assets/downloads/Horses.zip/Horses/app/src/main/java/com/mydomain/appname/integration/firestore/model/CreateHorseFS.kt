package com.mydomain.appname.integration.firestore.model

class CreateHorseFS(val Name:String)