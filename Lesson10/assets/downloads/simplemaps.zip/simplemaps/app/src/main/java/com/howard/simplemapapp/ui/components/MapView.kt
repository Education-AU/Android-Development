package com.howard.simplemapapp.ui.components

import android.location.Location
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.Dash
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.Polyline
import com.google.maps.android.compose.rememberCameraPositionState

@Composable
fun MapView(locations: List<Location>) {

    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(
            locations[0].let { LatLng(it.latitude, it.longitude) }, 15f
        )
    }

    GoogleMap(cameraPositionState=cameraPositionState) {
        Polyline(
            color = Color.Magenta,
            pattern = listOf(Dash(2f)),
            points = locations.map { LatLng(it.latitude, it.longitude) }
        )
        Marker(
            state = MarkerState(
                position = locations[0].let { LatLng(it.latitude, it.longitude) }),
            title = "TEST",
            snippet = "Marker in:"
        )
    }
}