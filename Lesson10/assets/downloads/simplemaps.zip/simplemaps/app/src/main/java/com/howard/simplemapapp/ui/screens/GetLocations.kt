package com.howard.simplemapapp.ui.screens

import android.content.pm.PackageManager
import android.location.Location
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.howard.simplemapapp.intergration.google.MapsService
import com.howard.simplemapapp.ui.components.MapView
import kotlinx.coroutines.launch

private const val PERMISSION = "android.permission.ACCESS_FINE_LOCATION"

@Composable
fun GetLocations(mapsService: MapsService) {

    val context = LocalContext.current
    val granted = remember {
        mutableStateOf(
            PackageManager.PERMISSION_GRANTED == ContextCompat.checkSelfPermission(
                context,
                PERMISSION
            )
        )
    }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        granted.value = isGranted
    }

    val locations = remember { mutableStateListOf<Location?>() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(key1 = Unit) {
        if (!granted.value) {
            launcher.launch(PERMISSION)
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(20.dp)) {
        Button(onClick = {
            scope.launch {
                locations.add(mapsService.getCurrentLocation())
            }
        }) {
            Text("GetLocation")
        }
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            locations.forEach {
                Text(it.toString())
            }
        }
        if (locations.isNotEmpty())
            MapView(locations.toList().filterNotNull())
    }
}