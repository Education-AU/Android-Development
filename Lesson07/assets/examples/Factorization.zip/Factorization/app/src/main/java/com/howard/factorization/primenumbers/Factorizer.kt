package com.howard.factorization.primenumbers

fun factorize(n: Long): List<Long> {
    val factors = mutableListOf<Long>()
    var remaining = n
    var divisor = 2L
    while (remaining > 1) {
        while (remaining % divisor == 0L) {
            factors.add(divisor)
            remaining /= divisor
        }
        divisor++
    }
    return factors
}