package com.howard.factorization.ui.component

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.howard.factorization.primenumbers.factorize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun Factorize() {
    val error = remember { mutableStateOf("") }
    val input = remember { mutableStateOf("") }
    val fact = remember { mutableStateOf(emptyList<Long>()) }
    val scope = rememberCoroutineScope()
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Button(enabled = error.value.isEmpty(), onClick = {
            scope.launch(Dispatchers.IO) {
                fact.value = factorize(input.value.toLongOrNull() ?: 0L)
            }

        }) {
            Text("factorize")
        }
        OutlinedTextField(value = input.value, onValueChange = {
            val inp = it.toLongOrNull()
            input.value = it
            if (inp == null) {
                error.value = "Input is not a valid number"
            } else if (inp < 2) {
                error.value = "Input must be greater than 1"
            } else
                error.value = ""
        })
        if (error.value.isNotEmpty()) {
            Text(error.value, color = MaterialTheme.colorScheme.error)
        }

        Column {
            fact.value.forEach { Text(it.toString()) }
        }
    }
}

