package dk.howard.coroutineinvestigations

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import dk.howard.coroutineinvestigations.ui.components.BlockingFetch
import dk.howard.coroutineinvestigations.ui.components.ScopeFetch
import dk.howard.coroutineinvestigations.ui.components.ScopeFetchContext
import dk.howard.coroutineinvestigations.ui.components.FetchLaunchedEffectContext
import dk.howard.coroutineinvestigations.ui.components.ScopeFetchException
import dk.howard.coroutineinvestigations.ui.components.SuperVisorScopeFetchException
import dk.howard.coroutineinvestigations.ui.components.DirectCatchException
import dk.howard.coroutineinvestigations.ui.theme.CoroutineInvestigationsTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CoroutineInvestigationsTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    BlockingFetch()
                    //ScopeFetch()
                    //ScopeFetchContext()
                    //FetchLaunchedEffectContext()
                    //ScopeFetchException()
                    //SuperVisorScopeFetchException()
                    //DirectCatchException()
                }
            }
        }
    }
}



