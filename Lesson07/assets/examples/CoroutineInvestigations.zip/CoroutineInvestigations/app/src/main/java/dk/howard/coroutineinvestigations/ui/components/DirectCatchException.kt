package dk.howard.coroutineinvestigations.ui.components

import android.util.Log
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import dk.howard.coroutineinvestigations.utils.fetchSuspend
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun DirectCatchException() {
    val counter = remember { mutableStateOf(0) }
    val fetchState = remember { mutableStateOf("Initial") }
    val scope = rememberCoroutineScope()

    Column {
        Button(onClick = { counter.value += 1 }) { Text("The Counter:${counter.value}") }
        Button(onClick = {
            scope.launch() {// not
                try {// enough
                    delay(1000)
                    Log.v("ScopeFetchException", "before exception")
                    throw Exception("test")
                    fetchState.value += fetchSuspend()
                } catch (e: Exception) {
                    Log.v("Caught Directly", "Caught exception: ${e.message}")
                    if (e is CancellationException) {
                        throw e;
                    }
                }
            }
            scope.launch() {
                delay(2000)
                fetchState.value += fetchSuspend() + "SECOND CALL"
                Log.v("ScopeFetchException", "Is never called?")
            }
        }) { Text("Scope fetch:${fetchState.value}") }
    }
}