package dk.howard.coroutineinvestigations.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import dk.howard.coroutineinvestigations.utils.fetch

@Composable
fun BlockingFetch() {
    val counter = remember { mutableStateOf(0) }
    val fetchState = remember { mutableStateOf("Initial") }
    Column {
        Button(onClick = { counter.value += 1 }) {
            Text("The Counter:${counter.value}")
        }
        Button(onClick = { fetchState.value += fetch() }) {
            Text("Blocking fetch:${fetchState.value}")
        }

    }
}