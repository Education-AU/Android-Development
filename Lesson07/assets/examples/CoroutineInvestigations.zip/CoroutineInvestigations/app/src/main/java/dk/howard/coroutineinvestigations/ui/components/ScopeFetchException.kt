package dk.howard.coroutineinvestigations.ui.components

import android.util.Log
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import dk.howard.coroutineinvestigations.utils.fetch
import dk.howard.coroutineinvestigations.utils.fetchSuspend
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.plus

@Composable
fun ScopeFetchException() {
    val counter = remember { mutableStateOf(0) }
    val fetchState = remember { mutableStateOf("Initial") }
    val handle = CoroutineExceptionHandler { _, exc ->
        Log.v("HANDLER", exc.message.toString())
    }
    val scope = rememberCoroutineScope()
    Column {
        Button(onClick = {
            counter.value += 1
        }) {
            Text("The Counter:${counter.value}")
        }
        Button(onClick = {

            scope.launch(Dispatchers.IO+handle) {// not enough
                delay(1000)
                Log.v("ScopeFetchException", "before exception")
                throw Exception("test")
                fetchState.value += fetchSuspend()
            }
            scope.launch {
                delay(2000)
                fetchState.value += fetchSuspend() + "SECOND CALL"
                Log.v("ScopeFetchException", "Is never called?")
            }
        }) {
            Text("Scope fetch:${fetchState.value}")
        }
    }
}