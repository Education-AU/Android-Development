package dk.howard.coroutineinvestigations.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import dk.howard.coroutineinvestigations.utils.fetch
import dk.howard.coroutineinvestigations.utils.fetchSuspend
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun ScopeFetchContext() {
    val counter = remember { mutableStateOf(0) }
    val fetchState = remember { mutableStateOf("Initial") }
    val scope = rememberCoroutineScope()
    Column {
        Button(onClick = { counter.value += 1 }) {
            Text("The Counter:${counter.value}")
        }
        Button(onClick = {
            scope.launch(Dispatchers.IO) {
                fetchState.value += fetch()
            }
        }) {
            Text("Scope fetch context:${fetchState.value}")
        }
    }
}