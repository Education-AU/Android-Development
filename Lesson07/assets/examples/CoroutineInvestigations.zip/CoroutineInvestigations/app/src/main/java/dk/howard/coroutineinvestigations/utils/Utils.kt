package dk.howard.coroutineinvestigations.utils

import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

const val TAG_UTIL = "UTILS"
fun doALot(time: Long) {
    val timeStart = System.currentTimeMillis()
    while (System.currentTimeMillis() < timeStart + time) {
        if ((System.currentTimeMillis() - timeStart).toInt() % 2000 == 1) {
            Log.v("DOALOT", "doing stuff in thread ${Thread.currentThread().name}")
        }
    }
}

fun fetch(): String {
    Log.v(TAG_UTIL, "Starting fetch in thread ${Thread.currentThread().name}")
    doALot(6000)
    Log.v(TAG_UTIL, "Done fetching in thread ${Thread.currentThread().name}")
    return "stuff";
}

suspend fun fetchSuspend(doThrow: Boolean = false): String {
    return withContext(Dispatchers.IO) {
        Log.v(TAG_UTIL, "Starting fetch suspend in thread ${Thread.currentThread().name}")
        if (doThrow) {
            throw Exception("Throw from fetchSuspend")
        }
        doALot(3000)
        Log.v(TAG_UTIL, "Done fetching suspend in thread ${Thread.currentThread().name}")
        return@withContext "suspend stuff";
    }
}

suspend fun fetchSuspendException(): String {
    return withContext(Dispatchers.IO) {
        Log.v(TAG_UTIL, "Starting fetch suspend in thread ${Thread.currentThread().name}")
        //delay(4000)
        doALot(1000)
        //throw Exception("DO ALOT FAILS")
        throw CancellationException("DO ALOT FAILS")
        doALot(5000)
        Log.v(TAG_UTIL, "Done fetching suspend in thread ${Thread.currentThread().name}")
        return@withContext "suspend stuff";
    }
}