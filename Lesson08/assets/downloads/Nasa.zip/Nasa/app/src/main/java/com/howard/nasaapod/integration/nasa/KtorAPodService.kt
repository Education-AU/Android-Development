package com.howard.nasaapod.integration.nasa

import android.util.Log
import com.howard.nasaapod.integration.nasa.model.NasaResponse
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.engine.android.Android
import io.ktor.client.network.sockets.ConnectTimeoutException
import io.ktor.client.plugins.DefaultRequest
import io.ktor.client.plugins.ResponseException
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.logging.LogLevel
import io.ktor.client.plugins.logging.Logging
import io.ktor.client.plugins.observer.ResponseObserver
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.url
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode
import io.ktor.serialization.kotlinx.json.json
import kotlinx.io.IOException
import kotlinx.serialization.json.Json
import java.time.LocalDate
import java.time.format.DateTimeFormatter


class KtorAPodService : NasaApod {
    companion object {
        private val formatter = DateTimeFormatter.ofPattern("yyMMdd")
        private const val BASE_URL =
            "https://science.nasa.gov/wp-json/wp/v2/apod-basic/"
    }

    private val client = HttpClient(Android) {
        install(ResponseObserver) {
            onResponse {
                Log.v("APOD SERVICE", it.status.value.toString())
                Log.v("APOD SERVICE", it.body())
            }
        }

        install(Logging) {
            level = LogLevel.ALL
        }
        install(ContentNegotiation) {
            json(Json {
                prettyPrint = true
                isLenient = true
                ignoreUnknownKeys = true

            })
        }
        install(DefaultRequest) {
            header(HttpHeaders.ContentType, ContentType.Application.Json)
            header(HttpHeaders.UserAgent, "NasaApp/1.0")

        }
    }

    override suspend fun get(date: LocalDate): NasaResponse {
        try {
            val url = "${BASE_URL}${date.format(formatter)}"
            val response = client.get() {
                url(url)
            }
            return NasaResponse.Success(response.body())

        } catch (e: ResponseException) {
            val status = e.response.status
            return when (status) {
                HttpStatusCode.BadRequest -> NasaResponse.Failure.BadRequestError(e.message.toString())
                HttpStatusCode.ServiceUnavailable -> NasaResponse.Failure.UnAvailable
                else ->
                    NasaResponse.Failure.GeneralError(e.message.toString())
            }
        } catch (e: ConnectTimeoutException) {
            return NasaResponse.Failure.NetworkError
        } catch (e: IOException) {
            return NasaResponse.Failure.GeneralError(e.message.toString())
        }

    }

    fun close() {
        client.close()
    }
}
