package com.howard.nasaapod.ui.components

import android.app.DatePickerDialog
import android.widget.DatePicker
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import coil.compose.SubcomposeAsyncImage
import com.howard.nasaapod.integration.nasa.KtorAPodService
import com.howard.nasaapod.integration.nasa.model.APod
import com.howard.nasaapod.integration.nasa.model.NasaResponse
import java.time.LocalDate

@Composable
fun ImageChooser() {
    val context = LocalContext.current
    val service = remember { KtorAPodService() }
    val now = LocalDate.now()
    val apod = remember { mutableStateOf<APod?>(null) }
    val date = remember { mutableStateOf(now) }
    val datePicker = DatePickerDialog(
        LocalContext.current,
        { p: DatePicker, _, _, _ ->
            date.value = LocalDate.of(p.year, p.month, p.dayOfMonth)
        }, now.year, now.monthValue, now.dayOfMonth
    )

    LaunchedEffect(key1 = date.value) {
        when (val res = service.get(date.value)) {
            is NasaResponse.Success -> apod.value = res.apod
            is NasaResponse.Failure -> Toast.makeText(context, res.message, Toast.LENGTH_SHORT)
                .show()
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            service.close()
        }
    }

    Column(modifier = Modifier.verticalScroll(state = rememberScrollState())) {
        Text("This is an ap showing daily pictures")
        Button(onClick = { datePicker.show() }) {
            Text("SelectDate")
        }
        if (apod.value != null) {
            Text(apod.value?.copyright?.let { "\u00A9" + it }
                ?: "There is no Copyright on this image")
            SubcomposeAsyncImage(
                model = apod.value?.url,
                loading = { CircularProgressIndicator() },
                contentDescription = "Nasa Image"
            )
            Text(apod.value?.explanation ?: "There is no explanation for this image")
        }

    }
}