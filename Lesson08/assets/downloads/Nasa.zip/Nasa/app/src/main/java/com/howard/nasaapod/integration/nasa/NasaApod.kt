package com.howard.nasaapod.integration.nasa

import com.howard.nasaapod.integration.nasa.model.NasaResponse
import java.time.LocalDate

interface NasaApod {
    suspend fun get(date: LocalDate): NasaResponse
}