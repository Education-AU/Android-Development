package com.example.httpclientapp.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.example.httpclientapp.integration.typicode.model.Post

@Composable
fun PostItem(post: Post) {
    Column {
        Row {
            Text("UserId:")
            Text(text = post.userId.toString())
        }
        Row {
            Text("Id:")
            Text(text = post.id.toString())
        }
        Row {
            Text("Title:")
            Text(text = post.title)
        }
        Row {
            Text("Body:")
            Text(text = post.body)
        }
    }
}