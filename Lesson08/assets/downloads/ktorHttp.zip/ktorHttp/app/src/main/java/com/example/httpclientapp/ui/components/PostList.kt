package com.example.httpclientapp.ui.components

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import com.example.httpclientapp.integration.typicode.KtorPostsService
import com.example.httpclientapp.integration.typicode.model.Post
import kotlinx.coroutines.delay

@Composable
fun PostList() {
    val postsService = remember { KtorPostsService() }
    val data = remember { mutableStateOf<List<Post>>(emptyList()) }
    val isLoading = remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        isLoading.value = true

        data.value = postsService.get()
        isLoading.value = false
    }
    DisposableEffect(Unit) {
        onDispose {
            postsService.close()
        }
    }
    if (isLoading.value) {
        Loader()
    } else {
        LazyColumn {
            items(data.value) {
                PostItem(post = it)
            }
        }
    }
}