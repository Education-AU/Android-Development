package com.example.httpclientapp.integration.typicode

import com.example.httpclientapp.integration.typicode.model.Post

interface PostsService {
    suspend fun get(): List<Post>
    suspend fun post(post: Post)
    suspend fun get(id: Int): Post?
    suspend fun getBy(title: String): List<Post>
}