package com.example.httpclientapp.integration.typicode

import android.util.Log
import com.example.httpclientapp.integration.typicode.model.User
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.engine.android.Android
import io.ktor.client.plugins.DefaultRequest
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.logging.LogLevel
import io.ktor.client.plugins.logging.Logging
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.url
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.json.Json

class KtorUsersService : UsersService {
    companion object {
        private const val BASE_URL = "https://jsonplaceholder.typicode.com/users"
    }

    private val client = HttpClient(Android) {

        install(Logging) {
            level = LogLevel.ALL
        }
        install(ContentNegotiation) {
            json(Json {
                prettyPrint = true
                isLenient = true
                ignoreUnknownKeys = true

            })
        }
        install(DefaultRequest) {
            header(HttpHeaders.ContentType, ContentType.Application.Json)
        }
    }

    override suspend fun get(): List<User> {
        return try {
            client.get {
                url(BASE_URL)
            }.body()
        } catch (e: Exception) {
            Log.v("USERS SERVICE", e.toString())
            Log.v("USERS SERVICE", e.stackTraceToString())
            Log.v("USERS SERVICE", e::class.qualifiedName.toString())
            emptyList()
        }
    }

    fun close() {
        client.close()
    }
}