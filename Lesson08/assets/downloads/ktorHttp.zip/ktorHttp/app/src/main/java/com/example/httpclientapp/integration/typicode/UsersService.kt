package com.example.httpclientapp.integration.typicode

import com.example.httpclientapp.integration.typicode.model.User

interface UsersService {

    suspend fun get(): List<User>
}