package com.example.httpclientapp.integration.typicode

import android.util.Log
import com.example.httpclientapp.integration.typicode.model.Post
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.engine.android.Android
import io.ktor.client.plugins.DefaultRequest
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.logging.LogLevel
import io.ktor.client.plugins.logging.Logging
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.parameter
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.request.url
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.InternalSerializationApi
import kotlinx.serialization.json.Json
import kotlin.math.log

class KtorPostsService : PostsService {
    init{
        Log.v(this::class.qualifiedName,"Init called")
    }
    companion object {
        private const val BASE_URL = "https://jsonplaceholder.typicode.com/posts"

    }

    private val client = HttpClient(Android) {
        install(Logging) {
            level = LogLevel.ALL
        }
        install(ContentNegotiation) {
            json(Json {
                isLenient = true
                ignoreUnknownKeys = true
            })
        }
        install(DefaultRequest) {
            header(HttpHeaders.ContentType, ContentType.Application.Json)
        }
    }


    override suspend fun get(): List<Post> {
        return try {
            client.get {
                url(BASE_URL)
            }.body()
        } catch (e: Exception) {
            Log.v("POSTS SERVICE", e.toString())
            emptyList()
        }

    }

    override suspend fun get(id: Int): Post? {
        return try {
            client.get {
                url("$BASE_URL/$id")
            }.body()
        } catch (e: Exception) {
            Log.v("POSTS SERVICE", e.toString())
            return null
        }
    }

    override suspend fun post(post: Post) {
        client.post {
            url(BASE_URL)
            setBody(post)
        }
    }

    override suspend fun getBy(title: String): List<Post> {
        return try {
            client.get {
                url(BASE_URL)
                parameter("title", title)

            }.body()
        } catch (e: Exception) {
            Log.v("POSTS SERVICE", e.toString())
            emptyList()
        }
    }

    fun close() {
        client.close()
    }
}

